# دفتر اقساط الصقر — مشروع Android

تطبيق Android باسم **دفتر اقساط الصقر**، مبني باستخدام WebView ويضم النسخة الحالية من دفتر الأقساط والحسابات والمصاريف داخل `app/src/main/assets/index.html`.

## جاهز للبناء السحابي
المشروع يحتوي على Workflow جاهز لـ GitHub Actions في:
`.github/workflows/build-apk.yml`

إعدادات البناء:
- AGP 8.6.1
- Gradle 8.7
- JDK 17
- compileSdk 35
- minSdk 23
- targetSdk 35

راجع `README_CLOUD_AR.md` لخطوات استخراج APK من GitHub Actions.

## البناء المحلي
إذا كان Gradle وAndroid SDK متوفرين محليًا:
`gradle :app:assembleDebug`

الناتج:
`app/build/outputs/apk/debug/app-debug.apk`
