# دفتر اقساط الصقر — جاهز للبناء السحابي

هذا المشروع مُجهز ليُبنى على خدمة بناء سحابية بدون الحاجة إلى Android Studio على جهازك.

## الإعداد المستخدم
- Android Gradle Plugin: 8.6.1
- Gradle: 8.7
- JDK: 17
- compileSdk: 35
- minSdk: 23
- targetSdk: 35
- applicationId: `com.saqr.ledger`
- APK الناتج: `دفتر_اقساط_الصقر-debug.apk`

## البناء السحابي عبر GitHub Actions
المشروع يحتوي بالفعل على:
`.github/workflows/build-apk.yml`

بعد رفع المشروع إلى GitHub:
1. افتح تبويب **Actions**.
2. اختر **Build دفتر اقساط الصقر APK**.
3. اضغط **Run workflow**.
4. بعد انتهاء البناء افتح نتيجة التشغيل.
5. من قسم **Artifacts** حمّل:
   **دفتر-اقساط-الصقر-APK**
6. فك الضغط وثبّت ملف APK على الهاتف.

يمكن أيضًا تشغيل البناء تلقائيًا عند عمل Push إلى `main` أو `master`.

## ملاحظة مهمة
هذا الـAPK من نوع **Debug** ومناسب للتجربة والتثبيت المباشر. للنشر على Google Play سنضيف لاحقًا توقيع Release ومفتاح رفع آمن.
