# دفتر اقساط الصقر — مشروع Android

هذا المشروع يحوّل النسخة الحالية من التطبيق إلى تطبيق Android يعمل بدون متصفح،
ويحفظ بيانات العملاء والحركات والمصاريف محليًا باستخدام WebView + localStorage.

## إخراج APK
1. افتح المجلد في Android Studio.
2. انتظر Gradle Sync.
3. من القائمة: Build → Build APK(s).
4. ستجد ملف APK في:
   `app/build/outputs/apk/debug/app-debug.apk`

اسم التطبيق: **دفتر اقساط الصقر**
معرّف الحزمة: `com.saqr.ledger`

> المشروع يحتاج Android Studio وAndroid SDK عند البناء. لا يحتاج اتصالًا بالإنترنت أثناء تشغيل التطبيق بعد تثبيته.
